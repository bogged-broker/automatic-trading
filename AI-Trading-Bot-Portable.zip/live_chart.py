import yfinance as yf
import pandas as pd
from dash import Dash, dcc, html
from dash.dependencies import Input, Output
import plotly.graph_objs as go

TICKER = "AAPL"

app = Dash(__name__)
app.title = f"📈 Live {TICKER} Stock Chart"

app.layout = html.Div(children=[
    html.H1(f"Live {TICKER} Chart (1m candles)", style={'textAlign': 'center'}),
    dcc.Graph(id='live-candle-chart'),
    dcc.Interval(id='update', interval=60*1000, n_intervals=0)
])

@app.callback(Output('live-candle-chart', 'figure'), [Input('update', 'n_intervals')])
def update_chart(n):
    df = yf.download(tickers=TICKER, period='1d', interval='1m')
    df.reset_index(inplace=True)

    fig = go.Figure(data=[go.Candlestick(
        x=df['Datetime'],
        open=df['Open'],
        high=df['High'],
        low=df['Low'],
        close=df['Close'],
        name='Candles'
    )])

    fig.update_layout(title=f"{TICKER} - Live Price", xaxis_rangeslider_visible=False)
    return fig

if __name__ == '__main__':
    app.run_server(debug=True)