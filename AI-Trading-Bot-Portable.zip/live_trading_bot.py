import os
import time
import numpy as np
import pandas as pd
import yfinance as yf
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.callbacks import ModelCheckpoint
from sklearn.preprocessing import MinMaxScaler
import alpaca_trade_api as tradeapi
import random
import datetime

TICKER = 'AAPL'
INTERVAL = '1m'
API_KEY = 'YOUR_ALPACA_API_KEY'
API_SECRET = 'YOUR_ALPACA_SECRET_KEY'
BASE_URL = 'https://paper-api.alpaca.markets'
MODEL_FILE = 'lstm_model.h5'
TRADE_QTY = 1

api = tradeapi.REST(API_KEY, API_SECRET, BASE_URL, api_version='v2')

def get_price_data(symbol=TICKER, period='5d', interval='1m'):
    df = yf.download(symbol, period=period, interval=interval)
    df = df[['Close']]
    df.dropna(inplace=True)
    return df

def prepare_data(df):
    scaler = MinMaxScaler(feature_range=(0, 1))
    scaled = scaler.fit_transform(df.values)

    x, y = [], []
    lookback = 60
    for i in range(lookback, len(scaled)):
        x.append(scaled[i-lookback:i])
        y.append(scaled[i])

    x, y = np.array(x), np.array(y)
    x = np.reshape(x, (x.shape[0], x.shape[1], 1))
    return x, y, scaler

def build_model(input_shape):
    model = Sequential()
    model.add(LSTM(units=50, return_sequences=True, input_shape=input_shape))
    model.add(LSTM(units=50))
    model.add(Dense(1))
    model.compile(optimizer='adam', loss='mean_squared_error')
    return model

def train_model():
    df = get_price_data()
    x, y, scaler = prepare_data(df)
    model = build_model((x.shape[1], 1))

    checkpoint = ModelCheckpoint(MODEL_FILE, save_best_only=True)
    model.fit(x, y, epochs=5, batch_size=32, callbacks=[checkpoint], verbose=1)

    return scaler

def load_trained_model():
    model = load_model(MODEL_FILE)
    return model

def quantum_decision(prob_up):
    random_threshold = random.uniform(0, 1)
    return prob_up > random_threshold

def live_trading_loop():
    print("🧠 Starting live trading...")
    model = load_trained_model()
    scaler = train_model()

    while True:
        try:
            now = datetime.datetime.now()
            df = get_price_data(period='2h')
            recent_data = df[-60:]

            scaled_data = scaler.transform(recent_data.values)
            X = np.array([scaled_data])
            X = X.reshape((1, 60, 1))
            predicted = model.predict(X)[0][0]

            current_price = recent_data.iloc[-1].values[0]
            predicted_price = scaler.inverse_transform([[predicted]])[0][0]
            prob_up = 1 if predicted_price > current_price else 0

            should_trade = quantum_decision(prob_up)

            if should_trade:
                print(f"💡 {now} | Signal: BUY | Predicted Price: ${predicted_price:.2f}")
                api.submit_order(
                    symbol=TICKER,
                    qty=TRADE_QTY,
                    side='buy',
                    type='market',
                    time_in_force='gtc'
                )
            else:
                print(f"⛔ {now} | Signal: HOLD | Predicted Price: ${predicted_price:.2f}")

        except Exception as e:
            print("⚠️ Error in loop:", e)

        time.sleep(60)

if __name__ == "__main__":
    if not os.path.exists(MODEL_FILE):
        print("🔧 No model found. Training new model...")
        train_model()

    live_trading_loop()