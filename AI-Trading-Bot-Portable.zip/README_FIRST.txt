✅ AI Trading Bot — Live Stock Trading (Paper Account)

1. INSTALL PYTHON:
   https://www.python.org/downloads/windows
   (Be sure to check "Add Python to PATH" during install)

2. INSTALL REQUIRED LIBRARIES:
   Open Command Prompt and run:
   pip install -r requirements.txt

3. ADD YOUR ALPACA PAPER CREDENTIALS:
   Open live_trading_bot.py and replace:
   API_KEY = 'YOUR_ALPACA_API_KEY'
   API_SECRET = 'YOUR_ALPACA_SECRET_KEY'

4. LAUNCH THE BOT:
   Double-click python_launcher.bat
   - One window runs the bot
   - Browser opens with live stock chart